<img src="/logo.png"  alt="..."/>
<?php /**PATH E:\Clever Marketing\Life-Golf\resources\views/components/application-logo.blade.php ENDPATH**/ ?>