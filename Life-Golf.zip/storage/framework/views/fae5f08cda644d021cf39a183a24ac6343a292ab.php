<?php echo e($slot); ?>

<?php /**PATH E:\Clever Marketing\Life-Golf\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>