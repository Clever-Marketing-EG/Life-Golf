<html lang="en">
<head>

    <title>Some title</title>
</head>
<body>
    Some Body Content
</body>
</html>
<?php /**PATH E:\Clever Marketing\Life-Golf\resources\views/mail.blade.php ENDPATH**/ ?>